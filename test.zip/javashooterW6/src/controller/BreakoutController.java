package controller;

import java.awt.event.KeyEvent;
import gameobjects.GameObject;
import playground.SpaceInvadersLevel;

public class BreakoutController extends CollisionAware4WayController {

  int lx ;
  int ux ;
  public BreakoutController(int lx, int ux, double egospeed) {
    super(egospeed);
	this.lx = lx ;
	this.ux = ux ;
  }
  
  
  public String[] allowedEvents() {
    return new String[] {"left","right"} ;
  }

  public int[] getDXs() {
    return new int[] {-1, 1, 0, 0, 0} ;
  }

  public int[] getDYs() {
    return new int[] {0, 0, 0, 0, 0} ;
  }

  // Block ego if we are too far left and right
  @Override  
  public void updateObject() {
    super.updateObject() ;
    
    if ((this.getX() > this.ux) || (this.getX() < this.lx)) {
		double vx = getVX() ;
		setVX(-vx ) ;
		applySpeedVector() ;
		setVX(0) ;
 	}
		
  }

  

}
