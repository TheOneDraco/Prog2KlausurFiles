package controller;
// TODO
import playground.PacmanLevel;

/**
 * This class controls the ghosts
 */
public class GhostController extends ObjectController {

  protected String ghostName ;
  protected int heading = 2; // 4 = start, 0 1 2 3 = left right up down

  public GhostController(String ghostName) {
    super() ;
    this.ghostName = ghostName ;
  }

  double getGridPosX(double x) {
    return (x-PacmanLevel.STARTX) / PacmanLevel.SPACE ;
  }

  double getGridPosY(double y) {
    return (y-PacmanLevel.STARTY) / PacmanLevel.SPACE ;
  }


  @Override
  public void updateObject() {
	// check whether ghost has recently been eaten and is recovering in his box
	Double rec = (Double)this.getOrCreateLevelFlag("enemy_"+this.ghostName+"_recovering", -1.) ;
	//System.out.println("") ;
    if (rec > 0) {
	  //System.out.println(this.ghostName+"_revocering") ;
      if (this.getGameTime()-rec > 5.) {
        setLevelFlag("enemy_"+this.ghostName+"_recovering", -1.) ;
      }
      this.setX(PacmanLevel.STARTX + 11*PacmanLevel.SPACE) ;
      this.setY(PacmanLevel.STARTY + 12*PacmanLevel.SPACE) ;
      return ;	  
	}
	
	// dx/dy = speed vector, only one entry can be nonzero. If so, it is +-1
    int dx = (int)(this.getVX() / Math.abs(this.getVX())) ;
    int dy = (int)(this.getVY() / Math.abs(this.getVY())) ;
    
    // continuous ghost location in grid coordinates
    double curposX = getGridPosX(getX()) ;
    double curposY = getGridPosY(getY()) ;
    
    // discrete grid position that best fits the ghost's location
    int intposX =  (int)(curposX+0.5) ;
    int intposY =  (int)(curposY+0.5) ;

    // percentage of penetration into adjacent grid cell
    double fracposX = curposX - intposX ;
    double fracposY = curposY - intposY ;

    int mapEntry = PacmanLevel.levelMap[intposY+dy][intposX+dx] ;

    // Rebound on walls: if ghost has peentrated sufficiently into next grid cell, we let it rebound
    if ((mapEntry == 1)&&(Math.abs(fracposX) < 0.2) && (Math.abs(fracposY)<0.2)) {
      this.setX(PacmanLevel.STARTX + intposX*PacmanLevel.SPACE) ;
      this.setY(PacmanLevel.STARTY + intposY*PacmanLevel.SPACE) ;
      this.heading = (int)(Math.random() * 4.) ;
      int [] dxs = {1,-1,0,0} ;
      int [] dys = {0,0,-1,1} ;
      this.setVX(PacmanLevel.EGOSPEED/2 * dxs[heading]) ;
      this.setVY(PacmanLevel.EGOSPEED/2 * dys[heading]) ;

    }

    
    applySpeedVector();
  }
}
