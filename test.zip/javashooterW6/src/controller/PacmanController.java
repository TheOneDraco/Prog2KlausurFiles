package controller;





import java.awt.Color;
import java.awt.event.KeyEvent;
import playground.*;
import controller.*;
import gameobjects.*;
import java.util.*;
import java.awt.event.*;


/** This class controls the pacman based on used inputs. 
 * It extends the normal controller in a) that is detects obstacles and reacts to illegal movements. 
 * b) paints the opening and cloisng pacman mouth looking into the right direction
 * Convention: all GameObjects that contain the string "border" are consider obstacles
 */
public class PacmanController extends CollisionAware4WayController  {
  int direction = 0 ;
  boolean mouthOpen = true ;
  double lastStep = 0.0 ;
  double savex, savey, savevx, savevy ;



  public PacmanController(double egoSpeed) {
    super(egoSpeed);

  }

  double getEgoGridPosX() {
    return (getX()-PacmanLevel.STARTX) / PacmanLevel.SPACE ;
  }

  double getEgoGridPosY() {
    return (getY()-PacmanLevel.STARTY) / PacmanLevel.SPACE ;
  }


  /** return tile type at pacman's location. Is (int) appropriate here instead of round?? 
   */
  int getCurrentTileType() {
    int x = (int)(getEgoGridPosX()) ;
    int y = (int)(getEgoGridPosY()) ;
    return PacmanLevel.levelMap[y][x] ;
  }


  /** Idea: execute a fake movement in the current direction and check for collisions. If there are any -->y illegal movement! 
   */
  @Override
  public boolean movementPossible(int reqState) {
	  
	// store old state
	double x = getX(), y = getY() ;
	double vx = getVX(), vy = getVY() ;
	
	// set speed corresponding to requested heading
	setVX(getDXs()[reqState]*getMovementSpeed()) ;
	setVY(getDYs()[reqState]*getMovementSpeed()) ;
	applySpeedVector() ;
	
	// clip to pacman grid
    clip2Grid() ;

    // check for collisions. we could do this here by simply looking up the pacman map
    boolean allowed = true ;
	LinkedList<GameObject> coll = this.getPlayground().collectObjects("border", false) ;
	for (GameObject go : coll) {
	  if (this.gameObject.collisionDetection(go)) {
	    //System.out.println("COLL"+getGameTime()) ;
	    allowed = false; 
	    break ;
	  }
    }
    
    // restore old pos and speeds
    this.setX(x); this.setY(y) ;
    this.setVX(vx); this.setVY(vy) ;
    
    return allowed ;
  }


  @Override
  public void executeMovement(int reqState) {
    super.executeMovement(reqState) ;
    PacmanObject po = (PacmanObject)(this.gameObject) ;
    
    clip2Grid() ;    
    
    // set heading dir of Pacman
    this.heading = reqState ;
    
    // communicate to artist to that mouth can be painted in right direction
    if (reqState  != 4) {
      int[] headings = {0,180,90,270 } ;
      po.setDirection(headings[this.heading]) ;
    }
  }
    
  
  private void clip2Grid() {
    PacmanObject po = (PacmanObject)(this.gameObject) ;
	  
    // clip pacman to grid axis perpendicular tio movement
	if (getVX() != 0) {
      double posY = Math.floor(getEgoGridPosY()+0.5);
      po.setY(PacmanLevel.STARTY + PacmanLevel.SPACE*posY) ;
    } else if (getVY() != 0.) {
      double posX = Math.floor(getEgoGridPosX()+0.5);
      po.setX(PacmanLevel.STARTX + PacmanLevel.SPACE*posX) ;		
	}
  }
  
  
  private void setGridPos(double x, double y) {
    setX(PacmanLevel.STARTX + x*PacmanLevel.SPACE) ;
    setY(PacmanLevel.STARTY + y*PacmanLevel.SPACE) ;
  }
  

  @Override
  public void updateObject() {
    PacmanObject po = (PacmanObject)(this.gameObject) ;
    
    // open and close mouth of Pacman periodicaly, pass status to Artist.
    double gt = this.getPlayground().getGameTime(); 
    if ((gt - this.lastStep) > 0.1) {
      this.lastStep = gt ;
      this.mouthOpen = !this.mouthOpen ;
      po.setMouthState(mouthOpen) ;
    }
    
    super.updateObject() ;
    
    // transport Pacman when he leaves on the left/right
    if (this.getCurrentTileType() == PacmanLevel.TILE_LTR) {  // left transporter
      this.setGridPos(19,13)  ;
    } else 
    if (this.getCurrentTileType() == PacmanLevel.TILE_RTR) {  // right transporter
      this.setGridPos(2,13) ;
    } 


  }

}
