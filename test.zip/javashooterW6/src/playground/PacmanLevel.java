package playground;

// import utilities.* ;
import java.awt.Color;
import java.awt.AlphaComposite;
import java.awt.Font;
import java.awt.font.*;

import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Rectangle2D ;

import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.font.TextAttribute;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.AttributedString;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;
import javax.imageio.ImageIO;
import collider.CircleCollider;
import collider.Collider;
import collider.RectCollider;
import controller.EnemyController;
import controller.GhostController;
import controller.FallingStarController;
import controller.LimitedTimeController;
import controller.ObjectController;
import controller.SimpleShotController;
import controller.PacmanController;
import controller.Simple4WayController;
import controller.LevelController;
import controller.CollisionAwareEgoController;
import gameobjects.AnimatedGameobject;
import gameobjects.FallingStar;
import gameobjects.GameObject;
import gameobjects.RectObject;
import gameobjects.EgoObject;
import gameobjects.TextObject;
import gameobjects.PacmanObject;
import java.util.Scanner;



/**
 * Class that realizes all the game logic of a SpaceInvaders-type level. This is the class that you
 * inerit from if you want to create your own SpaceInvaders-tpe levels. Functions performed by this
 * class are:
 * <ul>
 * <li>initially set up the level, spawn all object etc., in method {@link #prepareLevel}
 * <li>define a game state machine, replay initial message and detect collisions in method
 * {@link #prepareLevel}
 * <li>create a lot of utility functions to redefine if you want to change a certain aspect of the
 * level
 * </ul>
 */
public class PacmanLevel extends Playground {
  public static final int POINTSX = 10 ;
  public static final int POINTSY = 10 ;
  public static final int STARTX = 50 ;
  public static final int STARTY = 50 ;
  public static final int SPACE = 20 ;
  public static final int BLOCKSIZE = 10 ;
  public static final int POINTSIZE = 4 ;
  public static final double PACSIZE = SPACE/2. - BLOCKSIZE/2. + SPACE/2. -1 ;
  public static final double GHOST_EAT_DURATION = 10 ;

  public static final double ENEMYSPEEDX = 80;
  public static final double ENEMYSPEEDY = 120;
  public static final double ENEMYSCALE = 0.3;
  public static final double STARTPERIOD = 3.;
  public static final double DYING_INTERVAL = 2.0;
  public static final int CANVASX = 500;
  public static final int CANVASY = 700;
  public static final int PAC_START_X = 2;
  public static final int PAC_START_Y = 25;
  public static final double EGOSPEED = 200;
  public static final double EGORAD = 15;

  public static final int TILE_WALL  = 1;
  public static final int TILE_GRAYWALL  = 4;
  public static final int TILE_PILL  = 2;
  public static final int TILE_EMPTY = 3;
  public static final int TILE_POINT = 0;
  public static final int TILE_LTR = 5;
  public static final int TILE_RTR = 6;
  public static final Color [] ghostColors = new Color[] {Color.RED, Color.GREEN, Color.YELLOW, Color.BLACK} ;  
  public static final String[] ghostNames = {"Inky", "Binky", "Pinky", "Clyde" } ;
  public static final int[][] ghostPositions = new int[][]{{11,13},{10,13},{11,13},{10,13}} ;
  


  protected boolean lost = false;
  protected boolean doneLevel = false;
  protected double startzeit = 0;
  int wallCount = 0 ;
  protected int points = 0 ;
  protected int nrPoints = 1000000 ;
  protected double storedX = -1 ;
  protected double storedY = -1 ;


  GameObject ego = null ;
  GameObject inky = null, pinky = null, binky = null, clyde = null ;

  /** 1 = wall, 2= pill, 0 = point, 3=empty, 4=greywall, 5=left transport, 6 = right transporter */
  public static int [][] levelMap = 
  {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
   {1,2,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,2,1}, 
   {1,0,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1}, 
   {1,0,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1}, 
   {1,0,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1}, 
   {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}, 
   {1,0,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,0,1}, 
   {1,0,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,0,1}, 
   {1,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,1}, 
   {1,1,1,1,1,0,1,1,1,3,1,3,1,1,1,0,1,1,1,1,1}, 
   {3,3,3,3,1,0,1,3,3,3,3,3,3,3,1,0,1,3,3,3,3}, 
   {3,3,3,3,1,0,1,3,1,4,4,4,1,3,1,0,1,3,3,3,3}, 
   {1,1,1,1,1,0,1,3,1,3,3,3,1,3,1,0,1,1,1,1,1}, 
   {3,5,3,3,3,0,3,3,1,3,3,3,1,3,3,0,3,3,3,6,3}, 
   {1,1,1,1,1,0,1,3,1,1,1,1,1,3,1,0,1,1,1,1,1}, 
   {3,3,3,3,1,0,1,3,3,3,3,3,3,3,1,0,1,3,3,3,3}, 
   {3,3,3,3,1,0,1,3,1,1,1,1,1,3,1,0,1,3,3,3,3}, 
   {1,1,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,1,1}, 
   {1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1}, 
   {1,0,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1}, 
   {1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1}, 
   {1,1,1,0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1}, 
   {1,1,1,0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1}, 
   {1,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,1}, 
   {1,0,1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,0,1}, 
   {1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,1}, 
   {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}} ; 


  public PacmanLevel() {
    super();
    this.canvasX = this.preferredSizeX();
    this.canvasY = this.preferredSizeY();
  }

  public String getName() {
    return "PacmanLevel"; 
  }

  public int preferredSizeX() {
    return CANVASX;
  }

  public int preferredSizeY() {
    return CANVASY;
  }


  public boolean resetRequested() {
    return false;
  }


  protected double calcEnemySpeedX() {
    return ENEMYSPEEDX;
  }


  protected double calcEnemySpeedY() {
    return ENEMYSPEEDY;
  }
  
  
  protected double calcEgoSpeed() {
	  return this.EGOSPEED ;
  }
  
  /** defines for how man secs ghost can be eaten after eating a pill) 
   */
  protected double calcGhostEatingDuration() {
    return this.GHOST_EAT_DURATION ;
  }


  ObjectController createEnemyController() {
    return new EnemyController();
  }


  protected String getStartupMessage() {
    
    return "Ready player 1!" ;
  }
  
  
  /* Resets ghosts to start positions. At beginnign of level or afrter pacman has died. 
   */
  protected void resetGhosts() {
    for (int i = 0; i < this.ghostNames.length; i++) {
      String ghostName = this.ghostNames[i] ; ;
      int[] ghostPos = this.ghostPositions[i] ; ;
      GameObject go = this.getObject("enemy_"+ghostName) ;
      go.setX(STARTX + ghostPos[0]*SPACE) ;
      go.setY(STARTY + ghostPos[1]*SPACE) ;
    }
  }
     


  public GameObject enemy(String name) {
    int index = -1 ;
    double x = -1 ;
    double y = -1 ;
    Color c = Color.WHITE ;
    for (int i = 0; i < 4; i++) {
      if (this.ghostNames[i].equals(name)) {
        x = this.ghostPositions[i][0] * SPACE + STARTX ;
        y = this.ghostPositions[i][1] * SPACE + STARTY ;
        c = this.ghostColors[i] ;
      }
    }
    RectObject ro = null ;
    ro = new RectObject("enemy_"+name, this, x,y,0,0, 15,15, c ) ;

    ObjectController oc = new GhostController(name) ;
    ro.setController(oc).generateColliders() ;
    ro.setVX(0) ;
    ro.setVY(-calcEgoSpeed()/2) ;
    addObject(ro) ;
    return ro ;    
  }



  protected void createGhosts() {
    // create enemies
    this.binky = enemy("Binky") ;
    this.pinky = enemy("Pinky") ;
    this.clyde = enemy("Clyde") ;
    this.inky = enemy("Inky") ;
  }


  protected void  point(int x,int y) {
        GameObject onePoint = new RectObject("point"+x+"/"+y, this, STARTX+x*SPACE,STARTY+y*SPACE,0,0,5,5, Color.WHITE).generateColliders() ;
        addObject(onePoint) ;
        this.points ++ ;
  }

  protected void  pill(int x,int y) {
        GameObject onePill = new RectObject("pill"+x+"/"+y, this, STARTX+x*SPACE,STARTY+y*SPACE,0,0,7,7, Color.CYAN).generateColliders() ;
        addObject(onePill) ;
        this.points ++ ;
  }


  protected void block(int x,int y) {
    GameObject leftW = new RectObject("obstacle border_ghost"+ (++this.wallCount), this, STARTX+SPACE*x, STARTY+SPACE*y, 0, 0, BLOCKSIZE, BLOCKSIZE, Color.WHITE) ;
    RectCollider rc = new RectCollider("block", leftW, SPACE-0.01, SPACE-0.01) ;
    leftW.addCollider(rc) ;
    addObject(leftW);
  }
 
  
  protected void grey_block(int x,int y) {
    GameObject leftW = new RectObject("obstacle border_ghost"+ (++this.wallCount), this, STARTX+SPACE*x, STARTY+SPACE*y, 0, 0, BLOCKSIZE, BLOCKSIZE, Color.GRAY) ;    
    RectCollider rc = new RectCollider("block", leftW, SPACE-0.01, SPACE-0.01) ;
    leftW.addCollider(rc) ;
    addObject(leftW);
  }       


  // 0 to 27 included vertical
  protected void createLabyrinth() {

    for (int y = 0; y < this.levelMap.length; y++) {
      for (int x = 0; x < this.levelMap[0].length; x++) {
        if (this.levelMap[y][x] == 1) {
          block(x,y) ;
        } else 
        if (this.levelMap[y][x] == 0) {
          point(x,y) ;          
        } else 
        if (this.levelMap[y][x] == 2) {
          pill(x,y) ;
        } else
        if (this.levelMap[y][x] == 4) {
          grey_block(x,y) ;
        } 
        

      }
    }
    this.nrPoints = this.points ;
    
  }


  protected void createEgoObject() {
    // add ego to playground at lower bottom
    PacmanController egoController = new PacmanController(this.calcEgoSpeed());

    this.ego = new PacmanObject("ego", this, STARTX+PAC_START_X*SPACE, STARTY+PAC_START_Y*SPACE, 0,0, PACSIZE )
      .setController(egoController) ;
      
    Collider c = new RectCollider("pac_coll", this.ego, SPACE-0.01,SPACE-0.01) ;
    this.ego.addCollider(c) ;

    addObject(ego);
  }


  protected void resetEgoObject() {
    this.ego.setX(STARTX+PAC_START_X*SPACE) ;
    this.ego.setY(STARTY+PAC_START_Y*SPACE) ;
  }


  void actionIfEgoEatsPoint(GameObject point) {
    deleteObject(point.getId()) ;
    // add to points counter
    Integer pts = (Integer) getGlobalFlag("points");
    pts++;
    setGlobalFlag("points", pts);
    this.nrPoints-- ;           
  }


  void actionIfEgoCollidesWithCollect(GameObject collect, GameObject ego) {
    double gameTime = this.getGameTime();
    this.setLevelFlag("gameStatus", "eatGhostsMode") ;
    this.startzeit = this.gameTime ;
    deleteObject(collect.getId()) ;
    this.nrPoints-- ;
  }

  void actionIfEgoCollidesWithEnemy(GameObject enemy, GameObject ego) {

    double gameTime = this.getGameTime();
    boolean eatGhostMode = getLevelFlag("gameStatus").equals("eatGhostsMode") ;
    
    // if we cannot eat ghosts, 1) we die 2) ghosts are reset to center 3) we are reset to bottom left corner
    if (eatGhostMode == false) {
      Integer lives = (Integer) getGlobalFlag("lives");
      lives--;
      setGlobalFlag("lives", lives);
      if (lives > 0) {
        this.setLevelFlag("gameStatus","dying") ;
      } else {
        this.setLevelFlag("gameStatus","gameOver") ;
      }
      this.startzeit = this.gameTime ;
      this.storedX = this.ego.getX() ;
      this.storedY = this.ego.getY() ;
    } else {
      Integer points = (Integer) getGlobalFlag("points");
      points+=10;
      setGlobalFlag("points", points) ;
      // todo: block ghost for 4 secs! 
      enemy.setX(STARTX + 10*SPACE) ;
      enemy.setY(STARTY+13*SPACE) ;
      enemy.setVX(0) ;
      enemy.setVY(-1*calcEgoSpeed()/2.) ;    
      setLevelFlag(enemy.getName()+"_recovering", this.getGameTime()) ;
    }

  }


  public GameObject getEgo() {
    return this.ego ;
  }


  /**
   * initially sets up the level. Not called by user, but called every time a layer is restarted
   * from scratch. So make sure that this is possible. Here, resources are loaded only once even if
   * method is called several times.
   * 
   * @param id String identifies level.
   */
  @Override
  public void prepareLevel(String id) {
    System.out.println("PREPARE");
    reset();
    resetFlags(FLAGS_LEVEL);

    // create and connect LevelController
    LevelController ctrl = new LevelController();
    this.setLevelController(ctrl) ;

    // set up flags that some objects rely on
    getOrCreateGlobalFlag("points", Integer.valueOf(0));
    getOrCreateGlobalFlag("level", Integer.valueOf(1));
    setLevelFlag("gameStatus", "start");
    getOrCreateGlobalFlag("lives", Integer.valueOf(3));
    setLevelFlag("dying", Double.valueOf(-1));
    
    // set up objects
    this.createEgoObject();
    this.createLabyrinth() ;
    this.createGhosts() ;    
  }
  
  
  protected void centeredText(Graphics2D g2, String text, Color fgColor, Color bgColor) {
      Font font = new Font("SansSerif", Font.PLAIN, 50);
      FontRenderContext frc = g2.getFontRenderContext();
      Rectangle2D textBounds = font.getStringBounds(text, frc);      
      AttributedString as4 = new AttributedString(text);
      as4.addAttribute(TextAttribute.FONT, font);
      as4.addAttribute(TextAttribute.FOREGROUND, fgColor);
      as4.addAttribute(TextAttribute.BACKGROUND, bgColor);
      g2.drawString(as4.getIterator(), (int)(this.CANVASX / 2 - textBounds.getWidth()/2.), this.CANVASY / 2);
  }   


  /** Draws mainly text that should be on top of everything else, and is thus drawn after everything else.
   */
  @Override
  public void redrawLevelAfter(Graphics2D g2) {
    String status = (String) getOrCreateLevelFlag("gameStatus", "playing") ;
    g2.setPaintMode() ;    
    
    if (status.equals("dying")) {
      centeredText(g2, "OUCH!!", Color.WHITE, Color.BLACK) ;
    }    
    else if (status.equals("gameOver")) {
      centeredText(g2, "GAME OVER", Color.WHITE, Color.BLACK) ;
    }        
    else if (status.equals("starting")) {
      centeredText(g2, this.getStartupMessage(), Color.GREEN, Color.BLACK) ;
    }
    else if (status.equals("levelFinished")) {
      centeredText(g2, "Level finished!", Color.GREEN, Color.BLACK) ;
    }    
    if (isPaused()) {
      centeredText(g2, "Paused!", Color.WHITE, Color.BLACK) ;       
    }
  }
  
  
  protected void drawText(Graphics2D g2, int size, String text, int x, int y, Color c) {
    Font drawFont = new Font("SansSerif", Font.PLAIN, size);
    AttributedString as = new AttributedString(text);
    as.addAttribute(TextAttribute.FONT, drawFont);
    as.addAttribute(TextAttribute.FOREGROUND, c);
    g2.drawString(as.getIterator(), x, y);
  }
	  


  /**
   * (re)draws the level but NOT the objects, they draw themselves. Called by the main game loop.
   * This method mainly draws the background and the scoreboard.
   * 
   * @param g2 Graphics2D object that can, and should be, draw on.
   */
  @Override
  public void redrawLevel(Graphics2D g2) {
    String status = (String) getOrCreateLevelFlag("gameStatus", "playing") ;

    // fill background with black
    int[] x = {0, canvasX, canvasX, 0};
    int[] y = {0, 0, canvasY, canvasY};
    Polygon bg = new Polygon(x, y, 4);
    if (status.equals("eatGhostsMode") == false) {
      g2.setColor(Color.BLACK);
    } else {
      g2.setColor(Color.BLUE);
    }    
    if (status.equals("dying") || status.equals("gameOver")) {
      g2.setColor(Color.RED) ;
    }
    g2.fill(bg);
        
    // draw score in upper left part of playground
    Integer pts = (Integer) getGlobalFlag("points");
    this.drawText(g2, 20, "Points: "+pts, 10, 20, Color.YELLOW) ;

    // draw lives counter in upper left part of playground
    Integer lives = (Integer) getGlobalFlag("lives");
    this.drawText(g2, 20, "Lives: "+pts, CANVASX-100, 20, Color.YELLOW) ;
    
  }


  /** Adds ego object, labyrinth and points and displays startup message. Is called from applyGameLogic */
  protected void firstIteration() {
    // start time measurement for knowing when message should disappear
    this.startzeit = this.getGameTime();
  }


  /**
   * applies the logic of the level. Mainly, this is a state machine governed by the level flag "gameStatus". 
   * This can have the values "start", "starting", "playing", "eatGhostMode", "dying" and "gameOver". 
   */
  @Override
  public void applyGameLogic() {
    double gameTime = this.getGameTime();
    String gameStatus = (String) getLevelFlag("gameStatus");
    
    

    if (gameStatus.equals("start") == true) {
      firstIteration();
      setLevelFlag("gameStatus", "starting");

    } else if (gameStatus.equals("starting") == true) {
      resetGhosts() ;
      resetEgoObject() ;
      if ((gameTime - startzeit) > this.STARTPERIOD) {
        setLevelFlag("gameStatus", "playing");
      }
    } else if ((gameStatus.equals("playing")) || (gameStatus.equals("eatGhostsMode")==true)) {
		
      // check for collisions of enemy and shots, reuse shots list from before..
      LinkedList<GameObject> enemies = collectObjects("enemy", false);
      LinkedList<GameObject> points = collectObjects("point", false);
      LinkedList<GameObject> pills = collectObjects("pill", false);


      // loop over enemies to check for collisions or suchlike ...
      for (GameObject p : points) {
        // if ego collides with enemy..
        if (ego.collisionDetection(p)) {
          actionIfEgoEatsPoint(p);
        }
      }

      for (GameObject e : enemies) {
        // if ego collides with enemy..
        if (ego.collisionDetection(e)) {
          actionIfEgoCollidesWithEnemy(e,ego);
        }
      }

      for (GameObject p : pills) {
        // if ego collides with enemy..
        if (ego.collisionDetection(p)) {
          actionIfEgoCollidesWithCollect(p,ego);
        }
      }
      
	  if (this.nrPoints <= 0) {
	    setLevelFlag("gameStatus", "levelFinished") ;
	    this.startzeit = this.gameTime ;
      }
      
    }  else 
    if (gameStatus.equals("dying")) {
      this.resetGhosts() ;
      this.ego.setX(this.storedX) ;
      this.ego.setY(this.storedY) ;
        
      if ((gameTime - this.startzeit) > this.DYING_INTERVAL) {
        setLevelFlag("gameStatus", "playing") ;
        this.resetEgoObject() ;
      }
    } else
    if (gameStatus.equals("gameOver")) {
      this.resetGhosts() ;
      this.ego.setX(this.storedX) ;
      this.ego.setY(this.storedY) ;
      if ((gameTime - this.startzeit) > this.DYING_INTERVAL) {
        this.lost = true ;
      }
    } // if (gameStatus == "playing")
    
    if (gameStatus.equals("eatGhostsMode")) {
      if ((this.gameTime-this.startzeit) > calcGhostEatingDuration()) {
        setLevelFlag("gameStatus", "playing") ;
      }
    
    }
    if (gameStatus.equals("levelFinished")) {
      if ((this.gameTime-this.startzeit) > 1.0) {
        this.doneLevel = true ;
        Integer lvl = (Integer) (getGlobalFlag("level")) ;
        setGlobalFlag("level", lvl+1) ;
      }    
    }           
  }

  public boolean gameOver() {
    return this.lost ;
  }

  public boolean levelFinished() {
    return this.doneLevel ;
  }



}
