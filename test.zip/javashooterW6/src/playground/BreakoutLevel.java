package playground;

import gameobjects.* ;
import java.util.* ;
import rendering.* ;
import java.util.LinkedList ;
import java.awt.Font;
import java.awt.font.*;
import java.awt.font.TextAttribute;
import java.text.AttributedString;


import java.awt.Polygon;


import java.awt.Graphics2D;
import java.awt.Color ;
import controller.* ;
import collider.* ;

/** There is a delay problem in this game and level. Has NOTHING to do
 *  with objects, flags and repainting, those all take conctant time evwen while lags occur.
 *  Might be to do with the genral repainting mechanism... 
 *  Curious: does NOT occurs for SpaceInvaders but for Pacman as well */
public abstract class BreakoutLevel extends Playground {
  TextObject counter = null ;
  TextObject lives = null ;
  
  public static final int OFFSETX = 20 ;
  public static final int OFFSETY = 30 ;

  
  protected GameObject ball = null, ego = null ;
  //ArrayList<GameObject> bricks = new ArrayList<GameObject>() ;
  
  protected int bricksLeft = 0;

  public BreakoutLevel() {
    super() ;
    this.canvasX = this.preferredSizeX();
    this.canvasY = this.preferredSizeY();
  }   
  
  /** signalisiert der GameEngine des Ende des Spiels. Hier erstmal immer false.
   * @return immer false
   */
  public boolean gameOver() {
    Boolean go = (Boolean)getOrCreateGlobalFlag("gameOver", false) ;
    return go ;
  }


  public String getName() {
    return "Level1" ;
  }

  
  
  /** signalisiert der GameEngine des Ende des Levels. Hier erstmal immer false.
   * @return immer false
   */
  public boolean levelFinished() {
	//System.out.println(this.bricksLeft) ;
    return (this.getCurrentBricks() <= 0) ;
  }
  
  
  /** signalisiert der GameEngine den Restart des Levels. Hier erstmal immer false.
   * @return immer false
   */
  public boolean resetRequested() {
    return false ;
  }
  
  
  protected void drawText(Graphics2D g2, int size, String text, int x, int y, Color c) {
    Font drawFont = new Font("SansSerif", Font.PLAIN, size);
    AttributedString as = new AttributedString(text);
    as.addAttribute(TextAttribute.FONT, drawFont);
    as.addAttribute(TextAttribute.FOREGROUND, c);
    g2.drawString(as.getIterator(), x, y);
  }
  
  
  /** Draw borders, points and lives.
   */ 
  public void redrawLevel(Graphics2D g2) {
    int[] x = {0, canvasX, canvasX, 0};
    int[] y = {0, 0, canvasY, canvasY};
    Polygon bg = new Polygon(x, y, 4);
    g2.setColor(Color.GRAY);
    g2.fill(bg); 
    
    int[] x2 = {OFFSETX, canvasX-OFFSETX, canvasX-OFFSETX, OFFSETX};
    int[] y2 = {OFFSETY, OFFSETY, canvasY-OFFSETY, canvasY-OFFSETY};
    Polygon bg2 = new Polygon(x2, y2, 4);
    g2.setColor(Color.BLACK);
    g2.fill(bg2); 
    
    Integer pts = (Integer) getGlobalFlag("points")     ;
    Integer lvs = (Integer) getGlobalFlag("lives")     ;
    
    this.drawText(g2, 20, "Points: "+pts, OFFSETX+20, 20, Color.YELLOW) ;
    this.drawText(g2, 20, "Lives: "+lvs, OFFSETX+500, 20, Color.YELLOW) ;
  }
  
  
  
  /** Signal that the level has a size of 700x700 pixels.
   * @return x size of level  
   */
  @Override
  public int preferredSizeX() {
    return 700;
  }

  /** Signal that the level has a size of 700x700 pixels.
   * @return y size of level  
   */
  @Override
  public int preferredSizeY() {
    return 700;
  }
  
  
  public int getCurrentBricks() {
    return this.bricksLeft ;
  }
  
  
  /** Method that gets called by applyGameLogic() of the superclass whenever the ball collides with a brick.
   * @param ball A referene to the urrentz ball object
   * @param brick A reference to the ego object
   */
  void actionIfBallHitsBrick(GameObject ball, GameObject brick) {
    this.deleteObject(brick.getId());
    this.bricksLeft-- ;
    ball.setVY(ball.getVY()*-1);
  }
  
  
  /** Method that gets called by applyGameLogic() of the superclass whenever the ball collides with the ego object.
   * @param ball A referene to the urrentz ball object
   * @param ego A reference to the ego object
   */  
  void actionIfBallHitsEgo(GameObject ball, GameObject ego) {
    ball.setVY(ball.getVY()*-1);

  }

  /** Models interactions between GameObjects. 
   * notably ball/ego and ball/brick.
   */
  @Override
  public void applyGameLogic() {

    // check for collision ball/brick
    LinkedList<GameObject> bricks = collectObjects("brick", false) ;
    
    for (GameObject brick : bricks) {
      if (this.ball.collisionDetection(brick)) {
        this.actionIfBallHitsBrick(this.ball, brick) ;
      }
    }
    
    // check for collisions ball/ego
    if (ego.collisionDetection(ball)) {
      actionIfBallHitsEgo(this.ball, this.ego) ;
    }    

    // check for gameOver condition
    Integer lives = (Integer)this.getGlobalFlag("lives") ;
    if (lives < 0) {
      setGlobalFlag("gameOver", true) ;
    }
  }
  
  
  /** Controls the width of created bricks in Pixels. Is used by #createBrick.
   * 
   * @return bricks size X in pixels
   */
  public abstract double getBrickSizeX()  ;
  
  /** Controls the height of created bricks in Pixels. Is used by #createBrick.
   * 
   * @return bricks size Y in pixels
   */
  public abstract double getBrickSizeY() ;

  
  /** Controls the x coordinate of the upper left point of the grid of bricks, in Pixels. Is used by #createBrick.
   * 
   * @return bricks start X in pixels
   */
  public abstract double getBrickStartX() ;

  
  /** Controls the y coordinate of the upper left point of the grid of bricks, in Pixels. Is used by #createBrick.
   * 
   * @return bricks start Y in pixels
   */
  public abstract double getBrickStartY() ;
  
  
  /** Controls the nr of bricks in the X direction.  Is used by #createBrick.
   * 
   * @return nr of bricks in X direction
   */
  public abstract int calcNrBricksX() ;

  
  /** Controls the nr of bricks in the Y direction.  Is used by #createBrick.
   * 
   * @return nr of bricks in Y direction
   */
  public abstract int calcNrBricksY() ;
  
  
  /** Computes speed of ego object, meant2be overwritten.
   */
  public double calcEgoSpeed() {
    return 350.0 ;
  }
  
  
  /** Creates the ego object and returns it, called by #prepareLevel. Does NOT add the ego object to the playground!
   *  
   * @return The created ego object instance (of class EgoObject)
   */
  public GameObject createEgoObject() {
    //System.out.println("prepare");
    RectObject ro = new RectObject("ego", this, 350, 550, 0, 0, 60,10, Color.BLUE) ;
    ro.generateColliders() ;
    Simple4WayController ec = new BreakoutController(OFFSETX, preferredSizeX()-OFFSETX, this.calcEgoSpeed()) ;
    ro.setController(ec) ;
    return ro ;
  }
  
  /** Creates the ball object and returns it, called by #prepareLevel. Does NOT add the ball object to the playground!
   *  
   * @return The created ball object instance (of class FallingStar)
   */
  public GameObject createBall() {
    GameObject co = new FallingStar("ball1", this, 300,300, 270, 270, Color.RED, 5) ;
    co.setController(new ReboundController(OFFSETX, OFFSETY))   ;
    return co ;
  }
  
  /** Creates the GameObject (RectObject) instance representing a single brick at a certain grid position. The brick is NOT added here! 
   * @param row row position in the grid, ranges from 0 to calcNrBricksY()-1
   * @param column column position in the grid of bricks, ranges from 0 to calcNrBricksX()-1
   * @return The GameObject instance (really a RectObject) representing the created brick.
   */
  public abstract GameObject createBrick(int row, int column) ;   
    
  /** Prepares a generic Breakout-Type level. This method relies on the methods #createEgo, #createBall and #createBrick, among others, which
   * are meant to be overwritten in subclasses.
   * @param level String passes by the game engine, is in principle obsolete and can be ignored  
   */
  @Override
  public void prepareLevel(String level) {
    this.bricksLeft = 0 ;
    for (int y = 0; y < this.calcNrBricksY(); y++ ) {
      for (int x = 0; x < this.calcNrBricksX(); x++ ) {
        GameObject tmp = this.createBrick(x,y) ;
        if (tmp != null) {
          this.addObject(tmp) ;      
          this.bricksLeft ++ ;
        }
      }
    }
    this.ego = this.createEgoObject() ;
    this.ball = this.createBall() ;
    this.addObject(this.ego) ;
    this.addObject(this.ball) ;
    
    // set up global flags
    this.setGlobalFlag("points",Integer.valueOf(0)) ;
    this.setGlobalFlag("lives",Integer.valueOf(3)) ;

    // create and connect LevelController
    LevelController ctrl = new LevelController();
    this.setLevelController(ctrl) ;

  }  
  



}
