import playground.ExperimentierLevel6;
import playground.Playground;

public class MyGame extends GameLoop {

	public MyGame() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Playground nextLevel(Playground currentLevel) {
		// TODO Auto-generated method stub
		return new ExperimentierLevel6();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyGame MyGame = new MyGame();
		MyGame.runGame(args);
	}

}

