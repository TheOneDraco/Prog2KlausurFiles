package playground;

import java.awt.Color;

import collider.RectCollider;
import controller.ReboundController;
import gameobjects.RectObject;

public class ExperimentierLevel6 extends SpaceInvadersLevel {

	public ExperimentierLevel6() {
		// TODO Auto-generated constructor stub
		
	}
	
	@Override
	public void prepareLevel(String id) {
		// TODO Auto-generated method stub
		super.prepareLevel(id);
		RectObject fly_enemy1 = new RectObject("fly_enemy1", this, 300, 300, 170, 70, 30, 30, Color.blue);
		addObject(fly_enemy1);
		fly_enemy1.setController(new ReboundController(nextShot, nextShot));
		fly_enemy1.addCollider(new RectCollider("fly_enemy1_collider", fly_enemy1, FLAGS_ALL, ENEMYSHOTSPEED));
		RectObject fly_enemy2 = new RectObject("fly_enemy2", this, 200, 200, 170, 70, 30, 30, Color.green);
		addObject(fly_enemy2);
		fly_enemy2.setObjectController(new ReboundController(nextShot, nextShot));
		fly_enemy2.addCollider(new RectCollider("fly_enemy2_collider", fly_enemy2, FLAGS_ALL, ENEMYSHOTSPEED));
	}
	@Override
	protected int calcNrEnemies() {
		
		return 5;
	}
	@Override
	protected String getStartupMessage() {
		// TODO Auto-generated method stub
		return "Experimentier Level 6";
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
