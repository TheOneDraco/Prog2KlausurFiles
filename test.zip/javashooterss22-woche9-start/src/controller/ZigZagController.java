package controller;


public class ZigZagController extends LimitedTimeController {
	int rad = 3;
	double g0 = -1;
	double duration = 0;
	double directioncounter = 0;
	public ZigZagController(double g0, double duration) {
		super(g0, duration);
		this.g0 = g0;
	    this.duration = duration;
	}
	
	@Override
	public void applySpeedVector() {
		double ts = this.getPlayground().getTimestep();
		
		
		directioncounter = directioncounter + ts;
		if(directioncounter <= 0.5) {
			gameObject.setX(this.getX() + 30 * ts);
			gameObject.setY(this.getY() + this.getVY() * ts);
			
		}else if(0.5< directioncounter && directioncounter <= 1){
			gameObject.setX(this.getX() - 30 * ts);
			gameObject.setY(this.getY() + this.getVY() * ts);
		} else {
			gameObject.setX(this.getX() - 30 * ts);
			gameObject.setY(this.getY() + this.getVY() * ts);
			directioncounter = 0;
		}
	    
	}
	@Override
	  public void updateObject() {
	    double gameTime = this.getPlayground().getGameTime();
	    applySpeedVector();

	    if (gameObject.getY() >= getPlayground().getSizeY() || gameObject.getY() < 0
	        || gameObject.getX() >= getPlayground().getSizeX() || gameObject.getX() < 0
	        || (gameTime - g0) > duration) {
	      // LinkedList<String> d = (LinkedList<String>) playground.getFlag("delete");
	      // d.add(gameObject.getId());
	      getPlayground().deleteObject(this.gameObject.getId());
	    }
	  }

}
