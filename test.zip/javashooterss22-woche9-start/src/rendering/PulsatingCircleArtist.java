package rendering;

import java.awt.Color;
import java.awt.Graphics2D;

import gameobjects.GameObject;

public class PulsatingCircleArtist extends Artist {

	protected double egoRad;
	protected Color color;
	public PulsatingCircleArtist(GameObject go) {
		super(go);
		this.egoRad = 15.0;
	}
	
	public PulsatingCircleArtist(GameObject go, double egoRad, Color color) {
		super(go);
	    this.egoRad = egoRad;
	    this.color = color;
	}

	@Override
	public void draw(Graphics2D g) {
		g.setColor(this.color);
	    double x = this.getX();
	    double y = this.getY();
	    int posX = (int) (x);
	    int posY = (int) (y);
	    int rad = (int) (2 * egoRad);
	    double thistime = getGameTime();
	    
	    if((thistime % 0.1)*10 >0.5) {
	    	g.fillOval((int)(posX-egoRad), (int)(posY-egoRad), (int)(rad), (int)(rad));
	    } else {
	    	g.fillOval((int)(posX - egoRad*1.3), (int)(posY-(egoRad*1.3)), (int)(rad*1.3), (int)(rad*1.3));
	    }
	    
	    
	}

}
