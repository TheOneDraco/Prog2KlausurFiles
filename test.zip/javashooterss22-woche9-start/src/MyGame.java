import java.awt.Color;

import controller.LimitedTimeController;
import controller.ZigZagController;
import gameobjects.GameObject;
import gameobjects.TextObject;
import playground.* ;

public class MyGame extends GameLoop {

  @Override
  public Playground nextLevel(Playground currentPlayground) {
    return new SpaceInvadersLevel() {
		
		@Override
		public String getName() {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		protected String getStartupMessage() {
			// TODO Auto-generated method stub
			
			return "Testlevel Zigzag und Blinken";
		}
		
		
		@Override
		protected GameObject createEnemyShotObject(GameObject parentObject, String name) {
			double gameTime = this.getGameTime();
		      ZigZagController ZigZagController = new ZigZagController(gameTime, 5.);
		      GameObject to =
		        new TextObject(name, this, parentObject.getX(), parentObject.getY(), 0, ENEMYSHOTSPEED, "I",
		            20, Color.YELLOW).generateColliders().setController(ZigZagController);
		      return to;
		}
	};
  }

  public static void main(String[] args) {

    MyGame mg = new MyGame() ;
    mg.runGame(args) ;
  }
}
