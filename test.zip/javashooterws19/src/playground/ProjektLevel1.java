package playground;

public class ProjektLevel1 extends SpaceInvadersLevel {

	public ProjektLevel1() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected String getStartupMessage() {
		// TODO Auto-generated method stub
		return "Level1";
	}
	@Override
	protected double calcEnemySpeedY() {
		// TODO Auto-generated method stub
		return 80;
	}
	@Override
	protected double calcEnemySpeedX() {
		// TODO Auto-generated method stub
		return 160;
	}
	@Override
	protected int calcNrEnemies() {
		// TODO Auto-generated method stub
		return 1;
	}
	
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Level1";
	}

}
