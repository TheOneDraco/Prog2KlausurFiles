package playground;

public class ProjektLevel2 extends SpaceInvadersLevel {

	public ProjektLevel2() {
		// TODO Auto-generated constructor stub
	}


	@Override
	protected String getStartupMessage() {
		// TODO Auto-generated method stub
		return "Level2";
	}
	@Override
	protected double calcEnemySpeedY() {
		// TODO Auto-generated method stub
		return 80;
	}
	@Override
	protected double calcEnemySpeedX() {
		// TODO Auto-generated method stub
		return 480;
	}
	@Override
	protected int calcNrEnemies() {
		// TODO Auto-generated method stub
		return 5;
	}
	
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Level2";
	}

}
