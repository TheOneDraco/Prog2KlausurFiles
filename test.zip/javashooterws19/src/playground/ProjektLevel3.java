package playground;

public class ProjektLevel3 extends SpaceInvadersLevel {

	public ProjektLevel3() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected String getStartupMessage() {
		// TODO Auto-generated method stub
		return "Level3";
	}
	@Override
	protected double calcEnemySpeedY() {
		// TODO Auto-generated method stub
		return 140;
	}
	@Override
	protected double calcEnemySpeedX() {
		// TODO Auto-generated method stub
		return 800;
	}
	@Override
	protected int calcNrEnemies() {
		// TODO Auto-generated method stub
		return 10;
	}
	
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Level3";
	}

}
