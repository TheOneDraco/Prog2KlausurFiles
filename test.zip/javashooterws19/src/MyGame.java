import playground.Playground;
import playground.ProjektLevel1;
import playground.ProjektLevel2;
import playground.ProjektLevel3;

public class MyGame extends GameLoop {

	public MyGame() {
		
	}

	@Override
	public Playground nextLevel(Playground currentLevel) {
		if(currentLevel == null) return new ProjektLevel1();
		if(currentLevel.getName().equals("Level1")) return new ProjektLevel2();
		if(currentLevel.getName().equals("Level2")) return new ProjektLevel3();
		if(currentLevel.getName().equals("Level3")) return new ProjektLevel1();
		else return null; 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyGame game = new MyGame();
		
		ProjektLevel1 ProjektLevel1 = new ProjektLevel1();
		System.out.println(ProjektLevel1.getName());
		ProjektLevel2 ProjektLevel2 = new ProjektLevel2();
		System.out.println(ProjektLevel2.getName());
		ProjektLevel3 ProjektLevel3 = new ProjektLevel3();
		System.out.println(ProjektLevel3.getName());
		game.runGame(args);
	}

}
