module schoolstuff {
}