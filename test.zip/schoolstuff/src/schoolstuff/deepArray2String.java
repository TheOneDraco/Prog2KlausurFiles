import java.util.Arrays;
package schoolstuff;

public class deepArray2String {
	public static String deepArray2String(int[][] a1) {
		    Arrays.deepToString(a1);
		    return a1;
	}
	public static void main(String[] args) {
		System.out.println(deepArray2String(new int[][] { { 1 }, { 2 }, { 4 } }));

	}

}
