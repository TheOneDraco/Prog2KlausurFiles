package schoolstuff;

public class compareIntArrays {

}
