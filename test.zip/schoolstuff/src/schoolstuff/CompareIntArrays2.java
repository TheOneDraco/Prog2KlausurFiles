package schoolstuff;

public class CompareIntArrays2 {
	public static boolean compareIntArraysMethode(int[] a1, int[] a2) {
	    int arrlength1 = a1.length;
	    int arrlength2 = a2.length;
	    int counter = 0;
	    if(arrlength1 == arrlength2){
	        for(int i = 0; i < arrlength1; ++i){
	            if(a1[i] == a2[i]){
	                counter++;
	            }            
	        }
	        if(counter == arrlength1){
	            return true;
	        }else{
	            return false;
	        }
	        
	    }
	    return false;
	  }

	
	public static void main(String[] args) {
		System.out.println(compareIntArraysMethode(new int[] { 1, 2, 3 }, new int[] { 1, 2, 3 }));
		System.out.println(compareIntArraysMethode(new int[] {}, new int[] {}));
		System.out.println(compareIntArraysMethode(new int[] {}, new int[] { 1 }));
	}

}
