package playground;

import java.awt.Color;

import controller.ObjectController;
import gameobjects.AnimatedGameobject;
import gameobjects.GameObject;

public class BossLevel2022 extends SpaceInvadersLevel {

	public BossLevel2022() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	protected String getStartupMessage() {
		// TODO Auto-generated method stub
		return "Boss-Level!";
	}
	@Override
	protected int calcNrEnemies() {
		// TODO Auto-generated method stub
		return 1;
	}
	
	@Override
	public void prepareLevel(String id) {
		// TODO Auto-generated method stub
		super.prepareLevel(id);
		
	}
	
	@Override
	protected GameObject createSingleEnemy(String name, double x_enemy, double y_enemy, double vx_enemy,
		double vy_enemy, ObjectController enemyController, double gameTime) {
		GameObject tmp = new AnimatedGameobject
		(name, this, 200.0, 200.0, 140.0, 40.0, 4.0, this.enemyAnim, gameTime, "loop")
		.setController(enemyController).generateColliders();
		return tmp;
	}
	
	@Override
	double calcEnemyShotProb() {
		return 0.01;
	}
	
	int hitcounter = 0;
	
	@Override
	void actionIfEnemyIsHit(GameObject e, GameObject shot) {
		
		double gameTime = this.getGameTime();
	    createExplosion(gameTime, e, "shard", DYING_INTERVAL, Color.BLUE);

	    ++hitcounter;
	    System.out.println("hit");
	    if(hitcounter >=25) {
	    	// delete enemy
	    	deleteObject(e.getId());
	    	deleteObject(shot.getId());
	    	// add to points counter
	    	Integer pts = (Integer) getGlobalFlag("points");
	    	setGlobalFlag("points", pts + 500);
	    	// reduce global enemies counter
	    	this.nrEnemies-- ;
	    }else {
	    	// delete shot
	    	deleteObject(shot.getId());
	    }
	}

}
