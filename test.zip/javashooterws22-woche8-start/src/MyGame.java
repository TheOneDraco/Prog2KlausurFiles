import playground.* ;

public class MyGame extends GameLoop {

  @Override
  public Playground nextLevel(Playground currentPlayground) {
    return new BossLevel2022();
  }
  

  public static void main(String[] args) {
    MyGame mg = new MyGame() ;
    mg.runGame(args) ;
  }
}
