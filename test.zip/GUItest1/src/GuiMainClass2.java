
import javax.swing.* ;
import javax.swing.text.TabStop;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.* ;

public class GuiMainClass2 implements ActionListener {
    JFrame main = null ;
    JPanel contentPane = null ;
    JMenuBar bar = null;
    JMenu jmenu = null;
    JMenuItem item1 = null;
    JMenuItem item2 = null;
    JMenuItem item3 = null;
    JLabel l1 = null ;
    JButton bl1 = null ;
    JButton bl2 = null ;
    JButton bl3 = null ;
    JButton br1 = null ;
    JButton br2 = null ;
    JButton br3 = null ;
    GridBagLayout gbl,gbl2 = null;
    GridBagConstraints gbc,gbc2 = null;
    JPanel p1,p2,p3,p4,p5,p6 ;
    ArrayList<Integer> printlist = new ArrayList<Integer>();
    boolean trigger = false;
    
    
    
    
    public void actionPerformed(ActionEvent ae) {
    	
        if (ae.getSource() == this.item1) {
            printlist.clear();
            l1.setText("");
        }else if(ae.getSource() == this.item2) {
        	for (Iterator<Integer> iterator = printlist.iterator(); iterator.hasNext();) {
				String outputstring = "";
				int temp = (Integer)iterator.next();
				if(temp==1) {
					outputstring = "Left1";
    			} else if(temp==2) {
    				outputstring ="Left2";
    			} else if(temp==3) {
    				outputstring ="Left3";
    			} else if(temp==11) {
    				outputstring ="Right1";
    			} else if(temp==12) {
    				outputstring ="Right2";
    			} else if(temp==13) {
    				outputstring ="Right3";
    			}
				System.out.println(outputstring);
			}
        }else if(ae.getSource() == this.item3) {
        	System.exit(0);
        }else if(ae.getSource() == this.bl1) {
        	printlist.add(1);
        	l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.bl2) {
        	printlist.add(2);
        	l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.bl3) {
        	printlist.add(3);
        	l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br1) {
        	printlist.add(11);
        	l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br2) {
        	printlist.add(12);
        	l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br3) {
        	printlist.add(13);
        	l1.setText(ArrayToString(printlist));
        }
    }
    
    public String ArrayToString(ArrayList<Integer> printlist) {
    	int tempcount = 0;
        String string = "";
    	for (Iterator<Integer> iterator = printlist.iterator(); iterator.hasNext();) {
    		int temp = (Integer)iterator.next();
    		if(tempcount >= 1) {
    			if(temp==1) {
    				string =string + "+Left1";
    			} else if(temp==2) {
    				string += "+Left2";
    			} else if(temp==3) {
    				string += "+Left3";
    			} else if(temp==11) {
    				string += "+Right1";
    				int temp2 = printlist.lastIndexOf(11);
    				if(printlist.get(temp2-1)==3&&printlist.get(temp2-2)==2&&printlist.get(temp2-3)==1&&temp2>=3) {
    					System.exit(0);
    				}
    			} else if(temp==12) {
    				string += "+Right2";
    			} else if(temp==13) {
    				string += "+Right3";
    			}
			
    		}else if(tempcount == 0){
    			if(temp==1) {
    				string = "Left1";
    				tempcount++;
    			} else if(temp==2) {
    				string ="Left2";
    				tempcount++;
    			} else if(temp==3) {
    				string ="Left3";
    				tempcount++;
    			} else if(temp==11) {
    				string ="Right1";
    				tempcount++;
    			} else if(temp==12) {
    				string ="Right2";
    				tempcount++;
    			} else if(temp==13) {
    				string ="Right3";
    				tempcount++;
    			}
    		}
		}
    	return string;
    }
    
    public GuiMainClass2() {
        this.main = new JFrame("Layout") ;
        this.contentPane = new JPanel() ;
        
        this.main.setContentPane(this.contentPane) ;
        this.bar = new JMenuBar();
        this.jmenu = new JMenu("File");
        this.item1 = new JMenuItem("Clear Queue");
        this.item1.addActionListener(this);
        this.item2 = new JMenuItem("Print Queue");
        this.item2.addActionListener(this);
        this.item3 = new JMenuItem("Exit");
        this.item3.addActionListener(this);
        this.main.setJMenuBar(bar);
        this.jmenu.add(item1);
        this.jmenu.add(item2);
        this.jmenu.add(item3);
        this.bar.add(jmenu);
        this.p1 = new JPanel() ;
        this.p2 = new JPanel() ;
        this.p3 = new JPanel() ;
        this.p4 = new JPanel() ;
        
        
        /*Layout*/


        this.gbl = new GridBagLayout();
        this.gbl2 = new GridBagLayout();
        this.gbc = new GridBagConstraints();
        this.gbc2 = new GridBagConstraints(); 

        this.contentPane.add(this.p1) ;
        //this.contentPane.add(this.p4);
        this.p1.add(this.p2) ;
        this.p1.add(this.p3) ;
        this.p2.setLayout(gbl);
        this.p3.setLayout(gbl);
        
        this.main.setSize(300,200) ;
        
        
        
        /*Buttons Links*/
        
        this.bl1 = new JButton("Left1") ;
        this.bl1.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.weightx = 1.0;
        this.gbc.gridy = 1;
        this.p2.add(bl1, gbc);
        
       
        this.bl2 = new JButton("Left2") ;
        this.bl2.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.gridy = 2;
        this.p2.add(this.bl2, gbc);

        
        this.bl3 = new JButton("Left3") ;
        this.bl3.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.anchor = GridBagConstraints.NORTH;
        this.gbc.gridy = 3;
        this.p2.add(this.bl3, gbc);
        

        /*Buttons Rechts*/

        this.br1 = new JButton("Right1") ;
        this.br1.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.weightx = 1.0;
        this.gbc.gridy = 1;
        this.p3.add(br1, gbc);
        
        
        this.br2 = new JButton("Right2") ;
        this.br2.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.gridy = 2;
        this.p3.add(this.br2, gbc);
        
        
        
        this.br3 = new JButton("Right3") ;
        this.br3.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.anchor = GridBagConstraints.NORTH;
        this.gbc.gridy = 3;
        this.p3.add(this.br3, gbc);
        
        
        this.l1 = new JLabel("");
        this.gbc2.fill = GridBagConstraints.HORIZONTAL;
        this.gbc2.anchor = GridBagConstraints.LINE_START;
        this.gbc2.weightx = 1.0;
        this.gbc2.gridy = 3;
        this.gbc2.gridx = 2;
        this.p4.add(this.l1, gbc2);
        this.contentPane.setLayout(gbl2);
        this.contentPane.add(this.p4, gbc);
       
        
        
        
        
       /* 
       this.printlist.add(1);
       this.printlist.add(2);
       this.printlist.add(12);
       this.printlist.add(13);
       System.out.println(printlist);
       */
        
      
        this.main.setVisible(true) ;   
                
                             
    }

    public static void main(String[] args) {
        GuiMainClass2 g = new GuiMainClass2() ;
    }

}
