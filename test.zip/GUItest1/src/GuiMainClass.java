
import javax.swing.* ;
import javax.swing.text.TabStop;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.* ;

public class GuiMainClass implements ActionListener {
    JFrame main = null ;
    JPanel contentPane = null ;
    JMenuBar bar = null;
    JMenu jmenu = null;
    JMenuItem item1 = null;
    JMenuItem item2 = null;
    JMenuItem item3 = null;
    JLabel l1 = null ;
    JButton bl1 = null ;
    JButton bl2 = null ;
    JButton bl3 = null ;
    JButton br1 = null ;
    JButton br2 = null ;
    JButton br3 = null ;
    GridBagLayout gbl,gbl2 = null;
    GridBagConstraints gbc,gbc2 = null;
    JPanel p1,p2,p3,p4,p5,p6 ;
    ArrayList<String> printlist = new ArrayList<String>();
    
    
    public void actionPerformed(ActionEvent ae) {
    	
        if (ae.getSource() == this.item1) {
            System.out.println("item1") ;
            printlist.clear();
            this.l1.setText("");
        }else if(ae.getSource() == this.item2) {
        	System.out.println("item2");
        	for (Iterator iterator = printlist.iterator(); iterator.hasNext();) {
        		System.out.println((String) iterator.next());
			}
        }else if(ae.getSource() == this.item3) {
        	System.out.println("item3");
        	System.exit(0);
        }else if(ae.getSource() == this.bl1) {
        	System.out.println("bl1");
        	this.printlist.add("Left1");
        	this.l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.bl2) {
        	System.out.println("bl2");
        	this.printlist.add("Left2");
        	this.l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.bl3) {
        	System.out.println("bl3");
        	this.printlist.add("Left3");
        	this.l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br1) {
        	System.out.println("br1");
        	this.printlist.add("Right1");
        	this.l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br2) {
        	System.out.println("br2");
        	this.printlist.add("Right2");
        	this.l1.setText(ArrayToString(printlist));
        }else if(ae.getSource() == this.br3) {
        	System.out.println("br3");
        	this.printlist.add("Right3");
        	this.l1.setText(ArrayToString(printlist));
        }/*else if() {
        	
        }else if() {
        	
        }*/
    }
    
    public String ArrayToString(ArrayList<String> printlist) {
    	String string = "";
    	boolean trigger = false;
    	for (Iterator iterator = printlist.iterator(); iterator.hasNext();) {
    		if(trigger == true) {
			string += "+" + (String) iterator.next();
    		}else {
    			string = (String) iterator.next();
    		trigger = true;
    		}
		}
    	return string;
    }
    
    public GuiMainClass() {
        this.main = new JFrame("Layout") ;
        this.contentPane = new JPanel() ;
        
        this.main.setContentPane(this.contentPane) ;
        this.bar = new JMenuBar();
        this.jmenu = new JMenu("jmenu File");
        this.item1 = new JMenuItem("item1 Clear Queue");
        this.item1.addActionListener(this);
        this.item2 = new JMenuItem("item2 Print Queue");
        this.item2.addActionListener(this);
        this.item3 = new JMenuItem("item3 Exit");
        this.item3.addActionListener(this);
        this.main.setJMenuBar(bar);
        this.jmenu.add(item1);
        this.jmenu.add(item2);
        this.jmenu.add(item3);
        this.bar.add(jmenu);
        this.p1 = new JPanel() ;
        this.p2 = new JPanel() ;
        this.p3 = new JPanel() ;
        this.p4 = new JPanel() ;
        
        /*Layout*/

        this.gbl = new GridBagLayout();
        this.gbl2 = new GridBagLayout();
        this.gbc = new GridBagConstraints();
        this.gbc2 = new GridBagConstraints(); 
        this.contentPane.add(this.p1) ;
        //this.contentPane.add(this.p4);
        this.p1.add(this.p2) ;
        this.p1.add(this.p3) ;
        this.p2.setLayout(gbl);
        this.p3.setLayout(gbl);
        
        this.main.setSize(300,200) ;
       
        
        
        /*Buttons Links*/
        
        this.bl1 = new JButton("Left1") ;
        this.bl1.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.weightx = 1.0;
        this.gbc.gridy = 1;
        this.p2.add(bl1, gbc);
        
       
        this.bl2 = new JButton("Left2") ;
        this.bl2.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.gridy = 2;
        this.p2.add(this.bl2, gbc);

        
        this.bl3 = new JButton("Left3") ;
        this.bl3.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.anchor = GridBagConstraints.NORTH;
        this.gbc.gridy = 3;
        this.p2.add(this.bl3, gbc);
        

        /*Buttons Rechts*/

        this.br1 = new JButton("Right1") ;
        this.br1.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.weightx = 1.0;
        this.gbc.gridy = 1;
        this.p3.add(br1, gbc);
        
        
        this.br2 = new JButton("Right2") ;
        this.br2.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.gridy = 2;
        this.p3.add(this.br2, gbc);
        
        
        
        this.br3 = new JButton("Right3") ;
        this.br3.addActionListener(this) ;
        this.gbc.fill = GridBagConstraints.HORIZONTAL;
        this.gbc.anchor = GridBagConstraints.NORTH;
        this.gbc.gridy = 3;
        this.p3.add(this.br3, gbc);
        
        
        this.l1 = new JLabel("");
        this.gbc2.fill = GridBagConstraints.HORIZONTAL;
        this.gbc2.anchor = GridBagConstraints.LINE_START;
        this.gbc2.weightx = 1.0;
        this.gbc2.gridy = 3;
        this.gbc2.gridx = 2;
        this.p4.add(this.l1, gbc2);
        
        this.contentPane.setLayout(gbl);
        this.contentPane.add(this.p4, gbc);
        
        
        this.main.setVisible(true) ;
        
          
                
                             
    }

    public static void main(String[] args) {
        GuiMainClass g = new GuiMainClass() ;
    }

}
